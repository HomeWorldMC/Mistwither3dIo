function love.conf(t)
    t.window.title = "Mistwither"
    t.window.fullscreen = true
    t.window.fullscreentype = "desktop"
    t.console = true
end
