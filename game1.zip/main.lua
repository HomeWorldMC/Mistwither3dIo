function love.load()
    relativemodemous = true

    virtual_width = love.graphics.getWidth()/2
    virtual_height = love.graphics.getHeight()/2

    canvas = love.graphics.newCanvas(virtual_width, virtual_height)
    
    love.mouse.setRelativeMode(relativemodemous)
    love.graphics.setDefaultFilter("nearest", "nearest")

    love.graphics.setBackgroundColor(0.05, 0.05, 0.05)
    
    textures = {}

    table.insert(textures,love.graphics.newImage("wall64x64.png"))
    table.insert(textures,love.graphics.newImage("door64x64.png"))

    texture_size=64

    doors = {}
    
    speedmult = 1

	h=virtual_height/3
    pi=3.141592

    movspdx=0
    movspdy=0

    sensitivity = 1.2

    screen_width = virtual_width --love.graphics.getWidth()
    screen_height = virtual_height --love.graphics.getHeight()

    mousex=0
    mousey=0

    omousex=0
    omousey=0

    mousedx=0
    mousedy=0

    camera_ang=4
    camera_x=8
    camera_y=8

    light_on = true

    room = {
        {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
        {1,0,1,1,0,1,1,1,0,0,0,1,1,1,1,1,1,0,1},
        {1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1},
        {1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1},
        {1,0,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
        {1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1},
        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1},
        {1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1},
        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
        {1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1},
        {1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1},
        {1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1},
        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
        {1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1},
        {1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1},
        {1,0,1,1,1,1,1,1,0,0,0,1,1,1,1,1,1,0,1},
        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
        {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
    }

    room_width = #room[1]
    room_height = #room 

    light_rolloff = 0.00395

    viewdist=4

    viewbounds_x1=camera_x-viewdist
	viewbounds_x2=camera_x+viewdist
	viewbounds_y1=camera_y-viewdist
	viewbounds_y2=camera_y+viewdist

    zbuffer={}
	for i=1,screen_width do
		table.insert(zbuffer,0)
	end

    love.window.setVSync(1)
end

function love.update(dt)
    viewbounds_x1=camera_x-viewdist
	viewbounds_x2=camera_x+viewdist
	viewbounds_y1=camera_y-viewdist
	viewbounds_y2=camera_y+viewdist

	if viewbounds_x1<0 then viewbounds_x1=0 end
	if viewbounds_x2>127 then viewbounds_x2=127 end

	if viewbounds_y1<0 then viewbounds_y1=0 end
	if viewbounds_y2>63 then viewbounds_y2=63 end

    controls() 
    docollisions()
end

function love.draw()
    
    love.graphics.setCanvas(canvas)
    love.graphics.clear()
    
    doraycasting()
    --drawdoors()


    love.graphics.setCanvas()

    

    local scaleX = love.graphics.getWidth() / virtual_width
    local scaleY = love.graphics.getHeight() / virtual_height

    love.graphics.setColor(1, 1, 1)
    love.graphics.draw(canvas, 0, 0, 0, scaleX, scaleY)

    crosshairs()
    love.graphics.print("fps="..love.timer.getFPS(), 5, 10)
    love.graphics.print("light_rolloff="..light_rolloff, 5, 28)
    love.graphics.print("camera_x="..camera_x..", camera_y="..camera_y..", camera_ang="..camera_ang, 5, 46)
    
end

function crosshairs()
    local w = 4
    
    love.graphics.setColor(0, 1, 0)
    
    love.graphics.line(love.graphics.getWidth()/2, love.graphics.getHeight()/2-w, love.graphics.getWidth()/2, love.graphics.getHeight()/2+w)
    love.graphics.line(love.graphics.getWidth()/2-w, love.graphics.getHeight()/2, love.graphics.getWidth()/2+w, love.graphics.getHeight()/2)
end

function draw_column(screen_x, wall_height, tex_x, color_intensity,tex_num)

    if light_on then
        love.graphics.setColor(math.max(color_intensity,0.2), math.max(color_intensity,0.2), math.max(color_intensity,0.2))
    else
        love.graphics.setColor(1, 1, 1)
    end

    --love.graphics.print("tex_num="..tex_num)

    local tex_w = textures[tex_num]:getWidth()
    local tex_h = textures[tex_num]:getHeight()

    -- Create a 1-pixel wide quad slice from texture
    local quad = love.graphics.newQuad(
        tex_x, 0,           -- x, y in texture
        1, tex_h,           -- width, height
        tex_w, tex_h
    )

    love.graphics.draw(
        textures[tex_num],
        quad,
        screen_x,
        virtual_height/2 - wall_height/2,  -- vertical center
        0,
        1,                    -- scale X
        wall_height / tex_h   -- scale Y
    )
end

function doraycasting()
    
	local iswall = false
    local isdoor = false
    local wall = 0

    local xc = screen_width/2
    local yc = screen_height/2

    local cam_x = camera_x
    local cam_y = camera_y

    local tex_x=0

    --h=50

	for sx=0,screen_width-1 do
		ray_x = math.cos(camera_ang + math.atan((sx-xc)/xc),1)
		ray_y = math.sin(camera_ang + math.atan((sx-xc)/xc),1)

		fac = math.cos(math.atan((sx-xc)/xc),1)		
		
		dx = math.abs(1/ray_x)
		dy = math.abs(1/ray_y)

		ix = ray_x > 0 and 1 or -1
		iy = ray_y > 0 and 1 or -1

		if ray_x > 0 then
			ray_offsetx = (math.floor(cam_x) - cam_x+1)/ray_x
		else
			ray_offsetx = math.abs((cam_x - math.floor(cam_x))/ray_x)
		end

		if ray_y > 0 then
			ray_offsety = (math.floor(cam_y) - cam_y + 1) / ray_y
		else
			ray_offsety = math.abs((cam_y - math.floor(cam_y)) / ray_y)
		end
		
		while true do
			if ray_offsetx < ray_offsety then
				cam_x = cam_x + ix
				d = ray_offsetx
				ray_offsetx = ray_offsetx + dx

                if cam_x >= 1 and cam_y >= 1 and cam_x < room_width+1 and cam_y < room_height+1 then
                    wall = room[math.floor(cam_x)][math.floor(cam_y)]  
                    if wall == 1 or wall > 2 then
                        tw = math.floor(yc-h/d/fac)
                        bw = math.floor(yc+h/d/fac)
                        color_intensity = 1 / (1 + d*d*light_rolloff)
                        tex_x = (cam_y + ray_y * d) % 1 * texture_size + (1 - 1) * 4                                    
                        draw_column(sx, bw-tw, tex_x, color_intensity,wall)
                        zbuffer[sx+1] = d
                        break                                                       
                    elseif wall == 2 then
                        d = d + 0.25/fac
                        tw = math.floor(yc-h/d/fac)
                        bw = math.floor(yc+h/d/fac)
                        color_intensity = 1 / (1 + d*d*light_rolloff)
                        tex_x = (cam_y + ray_y * d) % 1 * texture_size + (1 - 1) * 4   
                        table.insert(doors,{sx, bw-tw-25, tex_x, color_intensity, wall})                                
                    end
                end
			else 
				cam_y = cam_y + iy
				d = ray_offsety
				ray_offsety = ray_offsety + dy				
                if cam_x >= 1 and cam_y >= 1 and cam_x < room_width+1 and cam_y < room_height+1 then
                    wall = room[math.floor(cam_x)][math.floor(cam_y)]
                    if wall == 1 or wall > 2 then
                        tw = math.floor(yc-h/d/fac)
                        bw = math.floor(yc+h/d/fac)
                        color_intensity = 1 / (1 + d*d*light_rolloff)
                        tex_x = (cam_x + ray_x * d) % 1 * texture_size + (1 - 1) * 4 
                        draw_column(sx, bw-tw, tex_x, color_intensity, wall)
                        zbuffer[sx+1] = d
                        break
                    elseif wall == 2 then
                        d = d + 0.25/fac
                        tw = math.floor(yc-h/d/fac)
                        bw = math.floor(yc+h/d/fac)
                        color_intensity = 1 / (1 + d*d*light_rolloff)
                        tex_x = (cam_x + ray_x * d) % 1 * texture_size + (1 - 1) * 4 
                        table.insert(doors,{sx, bw-tw-25, tex_x, color_intensity, wall})                                                                                    
                    end
                end
			end		
            if cam_x > room_width or cam_y > room_height or cam_x < 1 or cam_y < 1 then
                break
            end	
		end
        iswall = false
        wall = 0
        cam_x = camera_x
        cam_y = camera_y
	end

    mousedx = 0
    mousedy = 0
end

function drawdoors()

    for d = 1, #doors do
        door = doors[d]
         draw_column(door[1], door[2], door[3], door[4], door[5])
    end
    doors={}
end

function controls() 
	local newpx = camera_x
	local newpy = camera_y

    movspd = 0.03 * speedmult

    if love.keyboard.isDown("d") then
        newpx = newpx - math.cos(camera_ang - pi/2) * movspd
		newpy = newpy - math.sin(camera_ang - pi/2) * movspd
    end

    if love.keyboard.isDown("a") then
        newpx = newpx + math.cos(camera_ang - pi/2) * movspd
		newpy = newpy + math.sin(camera_ang - pi/2) * movspd
    end

    if love.keyboard.isDown("w") then
        newpx = newpx + math.cos(camera_ang) * movspd
		newpy = newpy + math.sin(camera_ang) * movspd
    end

    if love.keyboard.isDown("s") then
        newpx = newpx - math.cos(camera_ang) * movspd
		newpy = newpy - math.sin(camera_ang) * movspd
    end	

    if love.keyboard.isDown("lshift") then
        speedmult = 2
    else
        speedmult = 1
    end	

    if relativemodemous then
        camera_ang = camera_ang + mousedx/200
        if camera_ang>2*pi then
            camera_ang=0
        end

        if camera_ang<0 then
            camera_ang=2*pi
        end
    end

	-- if not collision
	camera_x = newpx
	camera_y = newpy


end

function love.keypressed(key)
    --print("you pressed "..key)
    if key == "escape" then
        relativemodemous = not relativemodemous        
        love.mouse.setRelativeMode(relativemodemous)
    end

    if key == "l" then
        light_on = not light_on
    end

    if key == "-" then
        light_rolloff = light_rolloff * 1.5
    end

    if key == "=" then
        light_rolloff = light_rolloff / 1.5
    end
end

function love.mousemoved(x,y,dx,dy,istouch)
    --print("dx="..dx..", dy="..dy)
    mousedx = dx*sensitivity
    mousedy = dy*sensitivity
end

function docollisions()
    local wall = room[math.floor(camera_x)-1][math.floor(camera_y)]
	if (wall ~= 0 and wall ~= 2) or camera_x<1 then
		camera_x = math.max(camera_x,math.floor(camera_x)+0.2)
	end

    wall = room[math.floor(camera_x)+1][math.floor(camera_y)]
	if (wall ~= 0 and wall ~= 2) or camera_x>room_width+1 then
		camera_x = math.min(camera_x,math.ceil(camera_x)-0.2)
	end

    wall = room[math.floor(camera_x)][math.floor(camera_y)-1]
	if (wall ~= 0 and wall ~= 2) or camera_y<1 then
		camera_y = math.max(camera_y,math.floor(camera_y)+0.2)
	end

    wall = room[math.floor(camera_x)][math.floor(camera_y)+1]
	if (wall ~= 0 and wall ~= 2) or camera_y>room_height+1 then
		camera_y = math.min(camera_y,math.ceil(camera_y)-0.2)
	end
end
