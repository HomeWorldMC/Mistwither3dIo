function love.load()
    relativemodemous = true

    mx1=0
    mx2=0
    my1=0
    my2=0

    screen_factor = 2

    virtual_width = ((love.graphics.getHeight()/screen_factor)*4/3)
    virtual_height = love.graphics.getHeight()/screen_factor

    virtual_screen_offsetx = (love.graphics.getWidth() - love.graphics.getHeight()*4/3)/2

    canvas = love.graphics.newCanvas(virtual_width, virtual_height)
    
    love.mouse.setRelativeMode(relativemodemous)
    love.graphics.setDefaultFilter("nearest", "nearest")

    love.graphics.setBackgroundColor(0.05, 0.05, 0.05)
    
    textures = {}

    table.insert(textures,love.graphics.newImage("wall64x64.png"))
    table.insert(textures,love.graphics.newImage("door64x64.png"))
    table.insert(textures,love.graphics.newImage("stone_floor64x64.png"))



    for i=1,#textures do
        textures[i]:setWrap("repeat", "repeat")
        textures[i]:setFilter("nearest", "nearest")
    end

    texture_size=64

    floor_texture = love.image.newImageData("wall64x64.png")

    doors = {}
    
    speedmult = 1

	h=virtual_height/2
    pi=3.141592

    movspdx=0
    movspdy=0

    mouse_sensitivity = 0.5

    mouse_dx=0

    global_dt = 0

    camera_ang=4
    camera_x=8
    camera_y=8

    fov = math.rad(60)

    light_on = true
    debug_on = true

    room = { -- 19x19
        {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
        {1,0,1,1,0,1,1,1,0,0,0,1,1,1,1,1,1,0,1},
        {1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1},
        {1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1},
        {1,0,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
        {1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1},
        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1},
        {1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1},
        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
        {1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1},
        {1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1},
        {1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1},
        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
        {1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1},
        {1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1},
        {1,0,1,1,1,1,1,1,0,0,0,1,1,1,1,1,1,0,1},
        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
        {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
    }

    room_width = #room[1]
    room_height = #room 

    light_rolloff = 0.00395

    viewdist=4

    viewbounds_x1=camera_x-viewdist
	viewbounds_x2=camera_x+viewdist
	viewbounds_y1=camera_y-viewdist
	viewbounds_y2=camera_y+viewdist

    zbuffer={}
	for i=1,virtual_width do
		table.insert(zbuffer,0)
	end

    love.window.setVSync(1)

    tline_shader = love.graphics.newShader([[
        extern Image tex;
        extern vec2 start_uv;
        extern vec2 step_uv;

        vec4 effect(vec4 color, Image _, vec2 texcoord, vec2 screen_coords)
        {
            float x = screen_coords.x;
            vec2 uv = start_uv + step_uv * x;
            return Texel(tex, uv);
        }
    ]])
    
end

function love.update(dt)
    viewbounds_x1=camera_x-viewdist
	viewbounds_x2=camera_x+viewdist
	viewbounds_y1=camera_y-viewdist
	viewbounds_y2=camera_y+viewdist

	if viewbounds_x1<0 then viewbounds_x1=0 end
	if viewbounds_x2>127 then viewbounds_x2=127 end

	if viewbounds_y1<0 then viewbounds_y1=0 end
	if viewbounds_y2>63 then viewbounds_y2=63 end

    controls(dt) 
    docollisions()
end

function love.draw()
    
    
    love.graphics.setCanvas(canvas)
    love.graphics.clear()
    
    drawfloor2() 
    doraycasting2()

    
    
    love.graphics.setCanvas()    

    --local scaleX = love.graphics.getWidth() / virtual_width *2
    --local scaleY = love.graphics.getHeight() / virtual_height *2

    love.graphics.setColor(1, 1, 1)
    love.graphics.draw(canvas, virtual_screen_offsetx, 0, 0, screen_factor, screen_factor)


    love.graphics.rectangle("line",virtual_screen_offsetx,0,virtual_width*screen_factor,virtual_height*screen_factor)

    -- love.graphics.rectangle("line",
    --     love.graphics.getWidth()/2 - 40, 
    --     love.graphics.getHeight()/2 - 200,80,80)

    --love.graphics.points(40*mx1 + love.graphics.getWidth()/2 , 40*my1 + love.graphics.getHeight()/2 - 160)
    
    crosshairs()

    if debug_on then
        love.graphics.print("fps="..love.timer.getFPS(), 5, 10)
        love.graphics.print("light_rolloff="..light_rolloff, 5, 28)
        love.graphics.print("camera_x="..camera_x..", camera_y="..camera_y..", camera_ang="..camera_ang, 5, 46)
        love.graphics.print("virtual_width="..virtual_width..", virtual_height="..virtual_height, 5, 64)
    end
end

function crosshairs()
    local w = 4
    
    love.graphics.setColor(0, 1, 0)
    
    love.graphics.line(love.graphics.getWidth()/2, love.graphics.getHeight()/2-w, love.graphics.getWidth()/2, love.graphics.getHeight()/2+w)
    love.graphics.line(love.graphics.getWidth()/2-w, love.graphics.getHeight()/2, love.graphics.getWidth()/2+w, love.graphics.getHeight()/2)
end

function draw_column(screen_x, wall_height, tex_x, color_intensity,tex_num)

    if light_on then
        love.graphics.setColor(math.max(color_intensity,0.2), math.max(color_intensity,0.2), math.max(color_intensity,0.2))
    else
        love.graphics.setColor(1, 1, 1)
    end

    --love.graphics.print("tex_num="..tex_num)

    local tex_w = textures[tex_num]:getWidth()
    local tex_h = textures[tex_num]:getHeight()

    -- Create a 1-pixel wide quad slice from texture
    local quad = love.graphics.newQuad(
        tex_x, 0,           -- x, y in texture
        1, tex_h,           -- width, height
        tex_w, tex_h
    )

    love.graphics.draw(
        textures[tex_num],
        quad,
        screen_x,
        virtual_height/2 - wall_height/2,  -- vertical center
        0,
        1,                    -- scale X
        wall_height / tex_h   -- scale Y
    )
end

function draw_row(screen_y, screen_w, rot, tex_x, tex_y, tex_num)
    local tex_w = textures[tex_num]:getWidth()
    local tex_h = textures[tex_num]:getHeight()

    -- Create a 1-pixel wide quad slice from texture
    local quad = love.graphics.newQuad(
        tex_x, tex_y,           -- x, y in texture
        tex_w, 1,           -- width, height
        tex_w, tex_h
    )

    love.graphics.setColor(1, 1, 1)
    love.graphics.draw( --love.graphics.draw( texture, quad, x, y, r, sx, sy, ox, oy, kx, ky )
        textures[tex_num],
        quad,
        0,screen_y,
        rot,      
        screen_w / tex_w, 1  -- scale Y
    )
end

function doraycasting()
    
	local iswall = false
    local isdoor = false
    local wall = 0

    local xc = virtual_width/2
    local yc = virtual_height/2

    local cam_x = camera_x
    local cam_y = camera_y

    local tex_x=0

    --h=50

	for sx=0,virtual_width-1 do
		ray_x = math.cos(camera_ang + math.atan((sx-xc)/xc),1)
		ray_y = math.sin(camera_ang + math.atan((sx-xc)/xc),1)
		fac = math.cos(math.atan((sx-xc)/xc),1)		

        tw = math.floor(yc-h/d/fac)
        bw = math.floor(yc+h/d/fac)
		
		dx = math.abs(1/ray_x)
		dy = math.abs(1/ray_y)

		ix = ray_x > 0 and 1 or -1
		iy = ray_y > 0 and 1 or -1

		if ray_x > 0 then
			ray_offsetx = (math.floor(cam_x) - cam_x+1)/ray_x
		else
			ray_offsetx = math.abs((cam_x - math.floor(cam_x))/ray_x)
		end

		if ray_y > 0 then
			ray_offsety = (math.floor(cam_y) - cam_y + 1) / ray_y
		else
			ray_offsety = math.abs((cam_y - math.floor(cam_y)) / ray_y)
		end
		
		while true do
			if ray_offsetx < ray_offsety then
				cam_x = cam_x + ix
				d = ray_offsetx
				ray_offsetx = ray_offsetx + dx

                if cam_x >= 1 and cam_y >= 1 and cam_x < room_width+1 and cam_y < room_height+1 then
                    wall = room[math.floor(cam_x)][math.floor(cam_y)]  
                    if wall == 1 or wall > 2 then
                        tw = math.floor(yc-h/d/fac)
                        bw = math.floor(yc+h/d/fac)
                        color_intensity = 1 / (1 + d*d*light_rolloff)
                        tex_x = (cam_y + ray_y * d) % 1 * texture_size + (1 - 1) * 4                                    
                        draw_column(sx, bw-tw, tex_x, color_intensity,wall)
                        zbuffer[sx+1] = d
                        break                                                       
                    elseif wall == 2 then
                        d = d + 0.25/fac
                        tw = math.floor(yc-h/d/fac)
                        bw = math.floor(yc+h/d/fac)
                        color_intensity = 1 / (1 + d*d*light_rolloff)
                        tex_x = (cam_y + ray_y * d) % 1 * texture_size + (1 - 1) * 4   
                        table.insert(doors,{sx, bw-tw-25, tex_x, color_intensity, wall})                                
                    end
                end
			else 
				cam_y = cam_y + iy
				d = ray_offsety
				ray_offsety = ray_offsety + dy				
                if cam_x >= 1 and cam_y >= 1 and cam_x < room_width+1 and cam_y < room_height+1 then
                    wall = room[math.floor(cam_x)][math.floor(cam_y)]
                    if wall == 1 or wall > 2 then
                        tw = math.floor(yc-h/d/fac)
                        bw = math.floor(yc+h/d/fac)
                        color_intensity = 1 / (1 + d*d*light_rolloff)
                        tex_x = (cam_x + ray_x * d) % 1 * texture_size + (1 - 1) * 4 
                        draw_column(sx, bw-tw, tex_x, color_intensity, wall)
                        zbuffer[sx+1] = d
                        break
                    elseif wall == 2 then
                        d = d + 0.25/fac
                        tw = math.floor(yc-h/d/fac)
                        bw = math.floor(yc+h/d/fac)
                        color_intensity = 1 / (1 + d*d*light_rolloff)
                        tex_x = (cam_x + ray_x * d) % 1 * texture_size + (1 - 1) * 4 
                        table.insert(doors,{sx, bw-tw-25, tex_x, color_intensity, wall})                                                                                    
                    end
                end
			end		
            if cam_x > room_width or cam_y > room_height or cam_x < 1 or cam_y < 1 then
                break
            end	
		end
        iswall = false
        wall = 0
        cam_x = camera_x
        cam_y = camera_y
	end

    local horizon = virtual_height/2

    tline_shader:send("tex", textures[3])

    for sy = horizon, virtual_height do
        local dy = sy - horizon
        local dist = (virtual_height / 2) / dy

        local x1 = camera_x - (math.cos(camera_ang + pi/2 )*dist - math.sin(camera_ang+pi/2)*dist)
        local y1 = camera_y - (math.sin(camera_ang + pi/2)*dist + math.cos(camera_ang+pi/2)*dist)

        local x2 = camera_x - (math.cos(camera_ang - pi/2)*dist + math.sin(camera_ang-pi/2)*dist)
        local y2 = camera_y - (math.sin(camera_ang - pi/2)*dist - math.cos(camera_ang-pi/2)*dist)

        --tline(x1, y1, x2, y2, sy, 1)
        tline(x1, y1, x2, y2, sy, 1)
    end

    love.graphics.setShader()
end

function doraycasting2()
    
	local iswall = false
    local isdoor = false
    local wall = 0

    local xc = virtual_width/2
    local yc = virtual_height/2

    local cam_x = camera_x
    local cam_y = camera_y

    local tex_x=0

    local dir_x = 0
    local dir_y = 0

    local plane_x = 0
    local plane_y = 0


	for sx=0,virtual_width-1 do
        dir_x = math.cos(camera_ang)
        dir_y = math.sin(camera_ang)

        -- perpendicular to direction
        plane_x = -dir_y * math.tan(fov / 2)
        plane_y =  dir_x * math.tan(fov / 2)

        local cam2_x = 2 * sx / virtual_width - 1  -- -1 → 1

        ray_x = dir_x + plane_x * cam2_x
        ray_y = dir_y + plane_y * cam2_x


		--ray_x = math.cos(camera_ang + math.atan((sx-xc)/xc),1)
		--ray_y = math.sin(camera_ang + math.atan((sx-xc)/xc),1)

		--fac = math.cos(math.atan((sx-xc)/xc),1)		
		
		dx = math.abs(1/ray_x)
		dy = math.abs(1/ray_y)

		ix = ray_x > 0 and 1 or -1
		iy = ray_y > 0 and 1 or -1

		if ray_x > 0 then
			ray_offsetx = (math.floor(cam_x) - cam_x+1)/ray_x
		else
			ray_offsetx = math.abs((cam_x - math.floor(cam_x))/ray_x)
		end

		if ray_y > 0 then
			ray_offsety = (math.floor(cam_y) - cam_y + 1) / ray_y
		else
			ray_offsety = math.abs((cam_y - math.floor(cam_y)) / ray_y)
		end
		
		while true do
			if ray_offsetx < ray_offsety then
				cam_x = cam_x + ix
				d = ray_offsetx
				ray_offsetx = ray_offsetx + dx

                if cam_x >= 1 and cam_y >= 1 and cam_x < room_width+1 and cam_y < room_height+1 then
                    wall = room[math.floor(cam_x)][math.floor(cam_y)]  
                    if wall == 1 or wall > 2 then
                        tw = math.floor(yc-h/d)
                        bw = math.floor(yc+h/d)
                        color_intensity = 1 / (1 + d*d*light_rolloff)
                        tex_x = (cam_y + ray_y * d) % 1 * texture_size + (1 - 1) * 4                                    
                        draw_column(sx, bw-tw, tex_x, color_intensity,wall)
                        zbuffer[sx+1] = d
                        break                                                       
                    elseif wall == 2 then
                        d = d + 0.25
                        tw = math.floor(yc-h/d)
                        bw = math.floor(yc+h/d)
                        color_intensity = 1 / (1 + d*d*light_rolloff)
                        tex_x = (cam_y + ray_y * d) % 1 * texture_size + (1 - 1) * 4   
                        table.insert(doors,{sx, bw-tw-25, tex_x, color_intensity, wall})                                
                    end
                end
			else 
				cam_y = cam_y + iy
				d = ray_offsety
				ray_offsety = ray_offsety + dy				
                if cam_x >= 1 and cam_y >= 1 and cam_x < room_width+1 and cam_y < room_height+1 then
                    wall = room[math.floor(cam_x)][math.floor(cam_y)]
                    if wall == 1 or wall > 2 then
                        tw = math.floor(yc-h/d)
                        bw = math.floor(yc+h/d)
                        color_intensity = 1 / (1 + d*d*light_rolloff)
                        tex_x = (cam_x + ray_x * d) % 1 * texture_size + (1 - 1) * 4 
                        draw_column(sx, bw-tw, tex_x, color_intensity, wall)
                        zbuffer[sx+1] = d
                        break
                    elseif wall == 2 then
                        d = d + 0.25
                        tw = math.floor(yc-h/d)
                        bw = math.floor(yc+h/d)
                        color_intensity = 1 / (1 + d*d*light_rolloff)
                        tex_x = (cam_x + ray_x * d) % 1 * texture_size + (1 - 1) * 4 
                        table.insert(doors,{sx, bw-tw-25, tex_x, color_intensity, wall})                                                                                    
                    end
                end
			end		
            if cam_x > room_width or cam_y > room_height or cam_x < 1 or cam_y < 1 then
                break
            end	
		end
        iswall = false
        wall = 0
        cam_x = camera_x
        cam_y = camera_y
	end
end

function drawdoors()

    for d = 1, #doors do
        door = doors[d]
         draw_column(door[1], door[2], door[3], door[4], door[5])
    end
    doors={}
end

function controls(dt) 
	local newpx = camera_x
	local newpy = camera_y

    local dir_x = math.cos(camera_ang)
    local dir_y = math.sin(camera_ang)

    local right_x = -dir_y
    local right_y = dir_x

    local move_x = 0
    local move_y = 0

    if love.keyboard.isDown("lshift") then
        speedmult = 2
    else
        speedmult = 1
    end	

    movspd = 3 * speedmult

    if love.keyboard.isDown("d") then
        move_x = move_x + right_x
        move_y = move_y + right_y  
    end

    if love.keyboard.isDown("a") then
        move_x = move_x - right_x
        move_y = move_y - right_y 
    end

    if love.keyboard.isDown("w") then
        move_x = move_x + dir_x
        move_y = move_y + dir_y   
    end

    if love.keyboard.isDown("s") then
        move_x = move_x - dir_x
        move_y = move_y - dir_y  
    end	

    local length = math.sqrt(move_x * move_x + move_y * move_y)
    if length > 0 then
        move_x = move_x / length
        move_y = move_y / length    
    end

    newpx = newpx + move_x * movspd * dt
    newpy = newpy + move_y * movspd * dt

    if relativemodemous then
        camera_ang = camera_ang + mouse_dx * mouse_sensitivity *dt
        if camera_ang>2*pi then
            camera_ang=0
        end

        if camera_ang<0 then
            camera_ang=2*pi
        end
    end

	-- if not collision
	camera_x = newpx
	camera_y = newpy

    mouse_dx = 0
end

function love.keypressed(key)
    --print("you pressed "..key)
    if key == "escape" then
        relativemodemous = not relativemodemous        
        love.mouse.setRelativeMode(relativemodemous)
    end

    if key == "l" then
        light_on = not light_on
    end

    if key == "-" then
        light_rolloff = light_rolloff * 1.5
    end

    if key == "=" then
        light_rolloff = light_rolloff / 1.5
    end

    if key == "f3" then
        debug_on = not debug_on
    end
end

function love.mousemoved(x,y,dx,dy,istouch)
    mouse_dx = dx
end

function docollisions()
    local wall = room[math.floor(camera_x)-1][math.floor(camera_y)]
	if (wall ~= 0 and wall ~= 2) or camera_x<1 then
		camera_x = math.max(camera_x,math.floor(camera_x)+0.2)
	end

    wall = room[math.floor(camera_x)+1][math.floor(camera_y)]
	if (wall ~= 0 and wall ~= 2) or camera_x>room_width+1 then
		camera_x = math.min(camera_x,math.ceil(camera_x)-0.2)
	end

    wall = room[math.floor(camera_x)][math.floor(camera_y)-1]
	if (wall ~= 0 and wall ~= 2) or camera_y<1 then
		camera_y = math.max(camera_y,math.floor(camera_y)+0.2)
	end

    wall = room[math.floor(camera_x)][math.floor(camera_y)+1]
	if (wall ~= 0 and wall ~= 2) or camera_y>room_height+1 then
		camera_y = math.min(camera_y,math.ceil(camera_y)-0.2)
	end
end

function drawfloor()
    local horizon = virtual_height/2

    tline_shader:send("tex", textures[3])

    for sy = horizon, virtual_height do
        local dy = sy - horizon
        local dist = (virtual_height / 2) / dy

        local x1 = camera_x - (math.cos(camera_ang + fov/2)*dist - math.sin(camera_ang + fov/2)*dist)
        local y1 = camera_y - (math.sin(camera_ang + fov/2)*dist + math.cos(camera_ang + fov/2)*dist)

        local x2 = camera_x - (math.cos(camera_ang - fov/2)*dist + math.sin(camera_ang - fov/2)*dist)
        local y2 = camera_y - (math.sin(camera_ang - fov/2)*dist - math.cos(camera_ang - fov/2)*dist)

        tline(x1, y1, x2, y2, sy, 1)
    end

    love.graphics.setShader()
end

function drawfloor2()
    local horizon = virtual_height / 2

    local dir_x = math.cos(camera_ang)
    local dir_y = math.sin(camera_ang)

    local plane_scale = math.tan(fov / 2)
    local plane_x = -dir_y * plane_scale
    local plane_y =  dir_x * plane_scale

    -- left and right edge rays
    local ray0_x = dir_x - plane_x
    local ray0_y = dir_y - plane_y

    local ray1_x = dir_x + plane_x
    local ray1_y = dir_y + plane_y

    tline_shader:send("tex", textures[3])

    for sy = horizon, virtual_height do
        local dy = sy - horizon
        local dist = (virtual_height / 2) / dy

        local x1 = camera_x + ray0_x * dist
        local y1 = camera_y + ray0_y * dist

        local x2 = camera_x + ray1_x * dist
        local y2 = camera_y + ray1_y * dist

        tline(x1, y1, x2, y2, sy, 1)
    end

    love.graphics.setShader()
end

function tline(x1, y1, x2, y2, sy, tex_num)
    local scale = 40
    local start_uv = {(x1*scale) / texture_size, (y1*scale) / texture_size}
    local step_uv = {((x2 - x1)*scale) / virtual_width / texture_size, ((y2 - y1)*scale)  / virtual_width / texture_size}

    tline_shader:send("start_uv", start_uv)
    tline_shader:send("step_uv", step_uv)
    love.graphics.setShader(tline_shader)
    love.graphics.rectangle("fill", 0, sy, virtual_width, 1)
    
end
